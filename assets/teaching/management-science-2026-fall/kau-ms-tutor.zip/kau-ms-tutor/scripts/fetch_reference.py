"""Download approved public course references with no login or dependencies."""
import argparse
import hashlib
import json
from pathlib import Path
import tempfile
import urllib.error
import urllib.request

BASE = 'https://kitaekim0819.github.io/assets/teaching/management-science-2026-fall/'
LIMIT = 50 * 1024 * 1024

class CourseRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not newurl.startswith(BASE):
            raise ValueError('Redirect outside the public course collection was refused')
        return super().redirect_request(req, fp, code, msg, headers, newurl)

def download(url):
    if not url.startswith(BASE):
        raise ValueError('Only public course URLs are allowed')
    with urllib.request.build_opener(CourseRedirect).open(url, timeout=30) as response:
        data = response.read(LIMIT + 1)
    if len(data) > LIMIT:
        raise ValueError('Reference exceeds download size limit')
    return data

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('filename', nargs='?', help='Original filename from the course index; omit to list files')
    parser.add_argument('--text', action='store_true', help='Fetch the selected document’s text companion')
    parser.add_argument('--cache-dir', type=Path, default=Path(tempfile.gettempdir()) / 'kau-ms-tutor-cache')
    args = parser.parse_args()
    manifest = json.loads(download(BASE + 'materials.json'))
    if not args.filename:
        for item in manifest['files']:
            print(item['filename'] + '\t' + item['title'])
        return
    item = next((x for x in manifest['files'] if x['filename'] == args.filename), None)
    if item is None:
        raise ValueError('Filename is not in the published course index')
    url = item['text_url'] if args.text else item['url']
    name = url.removeprefix(BASE)
    if '/' in name or '\\' in name or name in ('', '.', '..'):
        raise ValueError('Invalid course filename')
    args.cache_dir.mkdir(parents=True, exist_ok=True)
    target = args.cache_dir / name
    expected = None if args.text else item['sha256']
    # Reuse originals only when they match the current public manifest.
    if expected and target.exists() and hashlib.sha256(target.read_bytes()).hexdigest() == expected:
        print(target)
        return
    data = download(url)
    if expected and hashlib.sha256(data).hexdigest() != expected:
        raise ValueError('Downloaded file does not match the published checksum; try again after deployment')
    target.write_bytes(data)
    print(target)

if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, StopIteration) as error:
        raise SystemExit('Could not retrieve course reference: ' + str(error) + '. Use an available browsing tool or ask the learner to upload the file; do not bypass network restrictions.')
