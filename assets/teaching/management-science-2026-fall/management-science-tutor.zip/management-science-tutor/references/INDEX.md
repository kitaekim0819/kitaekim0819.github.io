# Course reference index

Bundled snapshot: Fall 2026. Read only the files relevant to the learner’s question. Paths below are relative to this index. Text companions may omit figures and mathematical notation; use originals to verify them.

## Management Science Syllabus (2026, Fall)

Type: course reference
- [Original](syllabus-management-science-syllabus-2026-fall.pdf)
- [Text](syllabus-management-science-syllabus-2026-fall.txt)

## Week 1 — Chapter 1 — Introduction (English)

Type: course reference
- [Original](lecture-slides-week-1-chapter-1-introduction-english.pdf)
- [Text](lecture-slides-week-1-chapter-1-introduction-english.txt)

## Week 1 — Chapter 2 — Linear Programming (English)

Type: course reference
- [Original](lecture-slides-week-1-chapter-2-linear-programming-english.pdf)
- [Text](lecture-slides-week-1-chapter-2-linear-programming-english.txt)

## Week 1 — Week 1_Course Introduction (Fall 2026)

Type: course reference
- [Original](lecture-slides-week-1-week-1-course-introduction-fall-2026.pdf)
- [Text](lecture-slides-week-1-week-1-course-introduction-fall-2026.txt)

## Week 2 — Chapter 3 — Analysis of LP Models

Type: course reference
- [Original](lecture-slides-week-2-chapter-3-analysis-of-lp-models.pptx)
- [Text](lecture-slides-week-2-chapter-3-analysis-of-lp-models.txt)

## Week 3 — Chapter 3 — Analysis of LP Models part 2

Type: course reference
- [Original](lecture-slides-week-3-chapter-3-analysis-of-lp-models-part-2.pptx)
- [Text](lecture-slides-week-3-chapter-3-analysis-of-lp-models-part-2.txt)

## Week 4 — Chapter 3 — Analysis of LP Models part 3 (slides)

Type: course reference
- [Original](lecture-slides-week-4-chapter-3-analysis-of-lp-models-part-3-slides.pptx)
- [Text](lecture-slides-week-4-chapter-3-analysis-of-lp-models-part-3-slides.txt)

## Week 5 — Chapter 4 Post-Optimal and Sensitivity Analysis (slides)

Type: course reference
- [Original](lecture-slides-week-5-chapter-4-post-optimal-and-sensitivity-analysis-slides.pptx)
- [Text](lecture-slides-week-5-chapter-4-post-optimal-and-sensitivity-analysis-slides.txt)

## Week 6 — Chapter 5 Business Applications of Linear Programming (Slides)

Type: course reference
- [Original](lecture-slides-week-6-chapter-5-business-applications-of-linear-programming-slides.pptx)
- [Text](lecture-slides-week-6-chapter-5-business-applications-of-linear-programming-slides.txt)

## Week 9 — [Chapter 7] Integer Programming (Slides)

Type: course reference
- [Original](lecture-slides-week-9-chapter-7-integer-programming-slides.pptx)
- [Text](lecture-slides-week-9-chapter-7-integer-programming-slides.txt)

## Chapter 2 — Additional examples for Chapter 2

Type: problem_set
- [Original](quizzes-chapter-2-additional-examples-for-chapter-2.pdf)
- [Text](quizzes-chapter-2-additional-examples-for-chapter-2.txt)
- [Matching solutions](quizzes-chapter-2-additional-examples-for-chapter-2-solutions.pdf)

## Chapter 2 — Quiz #1

Type: problem_set
- [Original](quizzes-chapter-2-quiz-1.pdf)
- [Text](quizzes-chapter-2-quiz-1.txt)
- [Matching solutions](quizzes-chapter-2-quiz-1-solutions.pdf)

## Chapter 3 — Additional examples for Chapter 3

Type: problem_set
- [Original](quizzes-chapter-3-additional-examples-for-chapter-3.docx)
- [Text](quizzes-chapter-3-additional-examples-for-chapter-3.txt)
- [Matching solutions](quizzes-chapter-3-additional-examples-for-chapter-3-solutions.docx)

## Chapter 3 — Quiz #2

Type: problem_set
- [Original](quizzes-chapter-3-quiz-2.pdf)
- [Text](quizzes-chapter-3-quiz-2.txt)
- [Matching solutions](quizzes-chapter-3-quiz-2-solutions.docx)

## Assginment #1

Type: problem_set
- [Original](assignments-assignment-1.pdf)
- [Text](assignments-assignment-1.txt)
- [Matching solutions](assignments-assignment-1-solutions.pdf)

## Assginment #1 - Solutions

Type: solutions
- [Original](assignments-assignment-1-solutions.pdf)
- [Text](assignments-assignment-1-solutions.txt)
- [Matching problem set](assignments-assignment-1.pdf)

## Chapter 2 — Additional examples for Chapter 2 with Solutions

Type: solutions
- [Original](quizzes-chapter-2-additional-examples-for-chapter-2-solutions.pdf)
- [Text](quizzes-chapter-2-additional-examples-for-chapter-2-solutions.txt)
- [Matching problem set](quizzes-chapter-2-additional-examples-for-chapter-2.pdf)

## Chapter 2 — Quiz #1 with Solutions

Type: solutions
- [Original](quizzes-chapter-2-quiz-1-solutions.pdf)
- [Text](quizzes-chapter-2-quiz-1-solutions.txt)
- [Matching problem set](quizzes-chapter-2-quiz-1.pdf)

## Chapter 3 — Additional examples for Chapter 3 with Solutions

Type: solutions
- [Original](quizzes-chapter-3-additional-examples-for-chapter-3-solutions.docx)
- [Text](quizzes-chapter-3-additional-examples-for-chapter-3-solutions.txt)
- [Matching problem set](quizzes-chapter-3-additional-examples-for-chapter-3.docx)

## Chapter 3 — Quiz #2 with Solutions

Type: solutions
- [Original](quizzes-chapter-3-quiz-2-solutions.docx)
- [Text](quizzes-chapter-3-quiz-2-solutions.txt)
- [Matching problem set](quizzes-chapter-3-quiz-2.pdf)
