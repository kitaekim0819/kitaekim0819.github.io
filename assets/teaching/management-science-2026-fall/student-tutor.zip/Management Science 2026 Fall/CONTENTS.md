# Course files

Snapshot: 2026-11-10. Separate solution files excluded.

- syllabus-management-science-syllabus-2026-fall.pdf
- lecture-slides-week-1-chapter-1-introduction-english.pdf
- lecture-slides-week-1-chapter-2-linear-programming-english.pdf
- lecture-slides-week-1-week-1-course-introduction-fall-2026.pdf
- lecture-slides-week-2-chapter-3-analysis-of-lp-models.pdf
- lecture-slides-week-3-chapter-3-analysis-of-lp-models-part-2.pdf
- lecture-slides-week-4-chapter-3-analysis-of-lp-models-part-3-slides.pdf
- lecture-slides-week-5-chapter-4-post-optimal-and-sensitivity-analysis-slides.pdf
- lecture-slides-week-6-chapter-5-business-applications-of-linear-programming-slides.pdf
- lecture-slides-week-9-chapter-7-integer-programming-slides.pdf
- quizzes-chapter-2-additional-examples-for-chapter-2.pdf
- quizzes-chapter-2-quiz-1.pdf
- quizzes-chapter-3-additional-examples-for-chapter-3.docx
- quizzes-chapter-3-quiz-2.pdf
- assignments-assignment-1.pdf
- week-7-chapter-5-practice.ipynb
- week-3-colab-basics.pdf
- week-4-quiz-3-python-codes-for-lp.pdf
- week-4-example-3-1.ipynb
- week-4-example-3-2.ipynb
- week-5-lp-examples.ipynb
- week-9-quiz-4-integer-programming.pdf
- week-10-network-models-and-transportation.pdf
- week-10-quiz-chapters-6-and-7.pdf