# Course references

Snapshot: 2026-11-10 | Revision: 2c26349f558c

Separate solution files are excluded.

- Management Science Syllabus (2026, Fall): [Text](text/syllabus-management-science-syllabus-2026-fall.txt) · [Original](originals/syllabus-management-science-syllabus-2026-fall.pdf)
- Week 1 — Chapter 1 — Introduction (English): [Text](text/lecture-slides-week-1-chapter-1-introduction-english.txt) · [Original](originals/lecture-slides-week-1-chapter-1-introduction-english.pdf)
- Week 1 — Chapter 2 — Linear Programming (English): [Text](text/lecture-slides-week-1-chapter-2-linear-programming-english.txt) · [Original](originals/lecture-slides-week-1-chapter-2-linear-programming-english.pdf)
- Week 1 — Week 1_Course Introduction (Fall 2026): [Text](text/lecture-slides-week-1-week-1-course-introduction-fall-2026.txt) · [Original](originals/lecture-slides-week-1-week-1-course-introduction-fall-2026.pdf)
- Week 2 — Chapter 3 — Analysis of LP Models: [Text](text/lecture-slides-week-2-chapter-3-analysis-of-lp-models.txt) · [Original](originals/lecture-slides-week-2-chapter-3-analysis-of-lp-models.pdf)
- Week 3 — Chapter 3 — Analysis of LP Models part 2: [Text](text/lecture-slides-week-3-chapter-3-analysis-of-lp-models-part-2.txt) · [Original](originals/lecture-slides-week-3-chapter-3-analysis-of-lp-models-part-2.pdf)
- Week 4 — Chapter 3 — Analysis of LP Models part 3 (slides): [Text](text/lecture-slides-week-4-chapter-3-analysis-of-lp-models-part-3-slides.txt) · [Original](originals/lecture-slides-week-4-chapter-3-analysis-of-lp-models-part-3-slides.pdf)
- Week 5 — Chapter 4 Post-Optimal and Sensitivity Analysis (slides): [Text](text/lecture-slides-week-5-chapter-4-post-optimal-and-sensitivity-analysis-slides.txt) · [Original](originals/lecture-slides-week-5-chapter-4-post-optimal-and-sensitivity-analysis-slides.pdf)
- Week 6 — Chapter 5 Business Applications of Linear Programming (Slides): [Text](text/lecture-slides-week-6-chapter-5-business-applications-of-linear-programming-slides.txt) · [Original](originals/lecture-slides-week-6-chapter-5-business-applications-of-linear-programming-slides.pdf)
- Week 9 — [Chapter 7] Integer Programming (Slides): [Text](text/lecture-slides-week-9-chapter-7-integer-programming-slides.txt) · [Original](originals/lecture-slides-week-9-chapter-7-integer-programming-slides.pdf)
- Chapter 2 — Additional examples for Chapter 2: [Text](text/quizzes-chapter-2-additional-examples-for-chapter-2.txt) · [Original](originals/quizzes-chapter-2-additional-examples-for-chapter-2.pdf)
- Chapter 2 — Quiz #1: [Text](text/quizzes-chapter-2-quiz-1.txt) · [Original](originals/quizzes-chapter-2-quiz-1.pdf)
- Chapter 3 — Additional examples for Chapter 3: [Text](text/quizzes-chapter-3-additional-examples-for-chapter-3.txt) · [Original](originals/quizzes-chapter-3-additional-examples-for-chapter-3.docx)
- Chapter 3 — Quiz #2: [Text](text/quizzes-chapter-3-quiz-2.txt) · [Original](originals/quizzes-chapter-3-quiz-2.pdf)
- Assginment #1: [Text](text/assignments-assignment-1.txt) · [Original](originals/assignments-assignment-1.pdf)
- Week 7 — Chapter 5 CVXPY Practice: [Text](text/week-7-chapter-5-practice.txt) · [Original](originals/week-7-chapter-5-practice.ipynb)
- Week 3 — Colab Basics: [Text](text/week-3-colab-basics.txt) · [Original](originals/week-3-colab-basics.pdf)
- Week 4 — Quiz 3 — Python Codes for LP Worksheet: [Text](text/week-4-quiz-3-python-codes-for-lp.txt) · [Original](originals/week-4-quiz-3-python-codes-for-lp.pdf)
- Week 4 — Example 3-1 — CVXPY: [Text](text/week-4-example-3-1.txt) · [Original](originals/week-4-example-3-1.ipynb)
- Week 4 — Example 3-2 — CVXPY: [Text](text/week-4-example-3-2.txt) · [Original](originals/week-4-example-3-2.ipynb)
- Week 5 — LP Examples — CVXPY Practice: [Text](text/week-5-lp-examples.txt) · [Original](originals/week-5-lp-examples.ipynb)
- Week 9 — Quiz 4 — Integer Programming: [Text](text/week-9-quiz-4-integer-programming.txt) · [Original](originals/week-9-quiz-4-integer-programming.pdf)
- Week 10 — Chapter 6 - Network Models and Transportation Problems: [Text](text/week-10-network-models-and-transportation.txt) · [Original](originals/week-10-network-models-and-transportation.pdf)
- Week 10 — Quiz for Chapters 6 and 7 - CVXPY Problems: [Text](text/week-10-quiz-chapters-6-and-7.txt) · [Original](originals/week-10-quiz-chapters-6-and-7.pdf)
